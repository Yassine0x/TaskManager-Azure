# ============================================================================
# Script de deploiement Azure - Projet TaskManager avec Key Vault
# Date: 12/11/2025
# Description: Deploiement automatise de l'infrastructure Azure avec securite renforcee
# ============================================================================

# Configuration de la gestion d'erreurs - Le script s'arrete en cas d'erreur
$ErrorActionPreference = "Stop"

# ============================================================================
# VARIABLES DE CONFIGURATION
# ============================================================================

# Generation d'un suffixe aleatoire pour garantir l'unicite des noms
$randomSuffix = Get-Random -Minimum 1000 -Maximum 9999

# Parametres globaux
$resourceGroup = "RG-TaskManager"
$location = "polandcentral"

# Parametres reseau
$vnetName = "VNet-TaskLab"
$vnetPrefix = "10.0.0.0/16"
$subnetName = "Subnet-App"
$subnetPrefix = "10.0.1.0/24"

# Parametres MySQL
$mysqlServerName = "taskmysql$randomSuffix"
$mysqlAdminUser = "adminstudent"
$mysqlAdminPassword = "admin"
$mysqlDatabase = "taskdb"

# Parametres App Service
$appServicePlan = "asp-task-linux"
$webAppName = "wa-taskmanager$randomSuffix"

# Parametres VM
$vmName = "vm-supervision"
$vmAdminUser = "student"

# Parametres Storage Account
$storageAccountName = "sttaskmanager$randomSuffix"

# Parametres Key Vault
$keyVaultName = "kv-taskmanager$randomSuffix"

# ============================================================================
# FONCTION: Afficher un message de progression
# ============================================================================
function Write-Progress-Message {
    param([string]$Message)
    Write-Host "`n========================================" -ForegroundColor Cyan
    Write-Host $Message -ForegroundColor Yellow
    Write-Host "========================================`n" -ForegroundColor Cyan
}

# ============================================================================
# DEBUT DU DEPLOIEMENT
# ============================================================================

try {
    Write-Progress-Message "DEMARRAGE DU DEPLOIEMENT AZURE TASKMANAGER"

    # ------------------------------------------------------------------------
    # ETAPE 1: Creation du groupe de ressources
    # ------------------------------------------------------------------------
    Write-Progress-Message "Etape 1/9: Creation du groupe de ressources"
    
    az group create `
        --name $resourceGroup `
        --location $location `
        
    
    if ($LASTEXITCODE -ne 0) { throw "Echec de la creation du groupe de ressources" }
    Write-Host "Groupe de ressources cree avec succes" -ForegroundColor Green

    # ------------------------------------------------------------------------
    # ETAPE 2: Creation du reseau virtuel
    # ------------------------------------------------------------------------
    Write-Progress-Message "Etape 2/9: Creation du reseau virtuel et sous-reseau"
    
    az network vnet create `
        --name $vnetName `
        --resource-group $resourceGroup `
        --address-prefix $vnetPrefix `
        --subnet-name $subnetName `
        --subnet-prefix $subnetPrefix `
        
    
    if ($LASTEXITCODE -ne 0) { throw "Echec de la creation du reseau virtuel" }
    Write-Host "Reseau virtuel cree avec succes" -ForegroundColor Green

    # ------------------------------------------------------------------------
    # ETAPE 3: Creation du serveur MySQL Flexible
    # ------------------------------------------------------------------------
    Write-Progress-Message "Etape 3/9: Creation du serveur MySQL Flexible"
    
    az mysql flexible-server create `
        --name $mysqlServerName `
        --resource-group $resourceGroup `
        --location $location `
        --admin-user $mysqlAdminUser `
        --admin-password $mysqlAdminPassword `
        --sku-name Standard_B1ms `
        --tier Burstable `
        --storage-size 20 `
        --version 8.0.21 `
        --public-access 0.0.0.0 `
        --database-name $mysqlDatabase `
        --yes `
        --output json
    
    if ($LASTEXITCODE -ne 0) { throw "Echec de la creation du serveur MySQL" }
    Write-Host "Serveur MySQL et base de donnees crees avec succes" -ForegroundColor Green

    # ------------------------------------------------------------------------
    # ETAPE 4: Creation du Key Vault
    # ------------------------------------------------------------------------
    Write-Progress-Message "Etape 4/9: Creation du Key Vault"
    
    az keyvault create `
        --name $keyVaultName `
        --resource-group $resourceGroup `
        --location $location `
        --enable-rbac-authorization false `
        
    
    if ($LASTEXITCODE -ne 0) { throw "Echec de la creation du Key Vault" }
    Write-Host "Key Vault cree avec succes" -ForegroundColor Green

    # Recuperation du FQDN MySQL pour la chaine de connexion
    $mysqlFqdn = az mysql flexible-server show `
        --resource-group $resourceGroup `
        --name $mysqlServerName `
        --query "fullyQualifiedDomainName" `
        --output tsv

    # Construction de la chaine de connexion MySQL
    $connectionString = "Server=$mysqlFqdn;Database=$mysqlDatabase;Uid=$mysqlAdminUser;Pwd=$mysqlAdminPassword;SslMode=Required;"

    # Stockage des secrets dans Key Vault
    Write-Host "Stockage des secrets dans Key Vault..." -ForegroundColor Cyan
    
    az keyvault secret set `
        --vault-name $keyVaultName `
        --name "mysql-server" `
        --value $mysqlFqdn `
        
    
    az keyvault secret set `
        --vault-name $keyVaultName `
        --name "mysql-username" `
        --value $mysqlAdminUser `
        
    
    az keyvault secret set `
        --vault-name $keyVaultName `
        --name "mysql-password" `
        --value $mysqlAdminPassword `
        
    
    az keyvault secret set `
        --vault-name $keyVaultName `
        --name "mysql-database" `
        --value $mysqlDatabase `
        
    
    az keyvault secret set `
        --vault-name $keyVaultName `
        --name "mysql-connection-string" `
        --value $connectionString `
        
    
    if ($LASTEXITCODE -ne 0) { throw "Echec du stockage des secrets" }
    Write-Host "Secrets stockes avec succes" -ForegroundColor Green

    # ------------------------------------------------------------------------
    # ETAPE 5: Creation du Plan App Service
    # ------------------------------------------------------------------------
    Write-Progress-Message "Etape 5/9: Creation du Plan App Service"
    
    az appservice plan create `
        --name $appServicePlan `
        --resource-group $resourceGroup `
        --location $location `
        --sku B1 `
        --is-linux `
        
    
    if ($LASTEXITCODE -ne 0) { throw "Echec de la creation du Plan App Service" }
    Write-Host "Plan App Service cree avec succes" -ForegroundColor Green

    # ------------------------------------------------------------------------
    # ETAPE 6: Creation de la Web App
    # ------------------------------------------------------------------------
    Write-Progress-Message "Etape 6/9: Creation de la Web App"
    
    az webapp create `
        --name $webAppName `
        --resource-group $resourceGroup `
        --plan $appServicePlan `
        --runtime "NODE:18-lts" `
        
    
    if ($LASTEXITCODE -ne 0) { throw "Echec de la creation de la Web App" }
    Write-Host "Web App creee avec succes" -ForegroundColor Green

    # ------------------------------------------------------------------------
    # ETAPE 7: Activation de Managed Identity et permissions Key Vault
    # ------------------------------------------------------------------------
    Write-Progress-Message "Etape 7/9: Configuration de Managed Identity et permissions"
    
    # Activation de l'identite managee systeme
    Write-Host "Activation de Managed Identity..." -ForegroundColor Cyan
    $principalId = az webapp identity assign `
        -n $webAppName `
        -g $resourceGroup `
        --query principalId -o tsv
    
    if ($LASTEXITCODE -ne 0) { throw "Echec de l'activation de Managed Identity" }
    Write-Host "Managed Identity activee - Principal ID: $principalId" -ForegroundColor Green

    # Attribution des permissions sur Key Vault (politique d'acces)
    Write-Host "Attribution des permissions Key Vault..." -ForegroundColor Cyan
    az keyvault set-policy `
        --name $keyVaultName `
        --object-id $principalId `
        --secret-permissions get list 
    
    if ($LASTEXITCODE -ne 0) { throw "Echec de l'attribution des permissions Key Vault" }
    Write-Host "Permissions Key Vault attribuees avec succes" -ForegroundColor Green

    # Configuration des references Key Vault dans App Settings
    Write-Host "Configuration des App Settings avec references Key Vault..." -ForegroundColor Cyan
    $keyVaultUri = "https://$keyVaultName.vault.azure.net/"
    
# Define your settings as an array of key=value strings
    $settings = @(
    "MYSQL_SERVER=@Microsoft.KeyVault(SecretUri=${keyVaultUri}/secrets/mysql-server/)"
    "MYSQL_USERNAME=@Microsoft.KeyVault(SecretUri=${keyVaultUri}/secrets/mysql-username/)"
    "MYSQL_PASSWORD=@Microsoft.KeyVault(SecretUri=${keyVaultUri}/secrets/mysql-password/)"
    "MYSQL_DATABASE=@Microsoft.KeyVault(SecretUri=${keyVaultUri}/secrets/mysql-database/)"
    "MYSQL_CONNECTION_STRING=@Microsoft.KeyVault(SecretUri=${keyVaultUri}/secrets/mysql-connection-string/)"
    )

    # Now run the Azure CLI command
    az webapp config appsettings set `
    --name $webAppName `
    --resource-group $resourceGroup `
    --settings $settings


        
    
    if ($LASTEXITCODE -ne 0) { throw "Echec de la configuration des App Settings" }
    Write-Host "App Settings configures avec succes" -ForegroundColor Green

    # ------------------------------------------------------------------------
    # ETAPE 8: Creation du Storage Account
    # ------------------------------------------------------------------------
    Write-Progress-Message "Etape 8/9: Creation du Storage Account"
    
    az storage account create `
        --name $storageAccountName `
        --resource-group $resourceGroup `
        --location $location `
        --sku Standard_LRS `
        --kind StorageV2 `
        
    
    if ($LASTEXITCODE -ne 0) { throw "Echec de la creation du Storage Account" }
    Write-Host "Storage Account cree avec succes" -ForegroundColor Green

    # Creation d'un conteneur pour les logs
    Write-Host "Creation du conteneur de logs..." -ForegroundColor Cyan
    az storage container create `
        --name logs `
        --account-name $storageAccountName `
        --auth-mode login `
        
    
    if ($LASTEXITCODE -ne 0) { throw "Echec de la creation du conteneur" }
    Write-Host "Conteneur de logs cree avec succes" -ForegroundColor Green

    # ------------------------------------------------------------------------
    # ETAPE 9: Creation de la VM de supervision
    # ------------------------------------------------------------------------
    Write-Progress-Message "Etape 9/9: Creation de la VM de supervision"
    
    Write-Host "Note: Assurez-vous que la cle SSH existe" -ForegroundColor Yellow
    
    # Verification de l'existence de la cle SSH
    $sshKeyPath = "$env:USERPROFILE\.ssh\id_rsa.pub"
    if (-not (Test-Path $sshKeyPath)) {
        Write-Host "Cle SSH non trouvee. Creation avec authentification par mot de passe..." -ForegroundColor Yellow
        
        az vm create `
            --resource-group $resourceGroup `
            --name $vmName `
            --image Ubuntu2204 `
            --admin-username $vmAdminUser `
            --admin-password "admin" `
            --size Standard_B1s `
            --vnet-name $vnetName `
            --subnet $subnetName `
            --public-ip-sku Standard `
            
    } else {
        az vm create `
            --resource-group $resourceGroup `
            --name $vmName `
            --image Ubuntu2204 `
            --admin-username $vmAdminUser `
            --ssh-key-values $sshKeyPath `
            --size Standard_B1s `
            --vnet-name $vnetName `
            --subnet $subnetName `
            --public-ip-sku Standard `
            
    }
    
    if ($LASTEXITCODE -ne 0) { throw "Echec de la creation de la VM" }
    Write-Host "VM de supervision creee avec succes" -ForegroundColor Green

    # ------------------------------------------------------------------------
    # CONFIGURATION D'AZURE MONITOR (optionnel)
    # ------------------------------------------------------------------------
    Write-Progress-Message "Configuration d'Azure Monitor"
    
    Write-Host "Activation des logs Application Insights..." -ForegroundColor Cyan
    az monitor app-insights component create `
        --app $webAppName `
        --location $location `
        --resource-group $resourceGroup `
        --application-type web `
        
    
    if ($LASTEXITCODE -eq 0) {
        $instrumentationKey = az monitor app-insights component show `
            --app $webAppName `
            --resource-group $resourceGroup `
            --query "instrumentationKey" `
            --output tsv
        
        az webapp config appsettings set `
            --name $webAppName `
            --resource-group $resourceGroup `
            --settings "APPINSIGHTS_INSTRUMENTATIONKEY=$instrumentationKey" `
            
        
        Write-Host "Azure Monitor configure avec succes" -ForegroundColor Green
    } else {
        Write-Host "Azure Monitor non configure (facultatif)" -ForegroundColor Yellow
    }

    # ========================================================================
    # RESUME DU DEPLOIEMENT
    # ========================================================================
    Write-Progress-Message "DEPLOIEMENT TERMINE AVEC SUCCES"
    
    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Green
    Write-Host "     INFORMATIONS DE DEPLOIEMENT TASKMANAGER" -ForegroundColor Green
    Write-Host "============================================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "Groupe de ressources    : $resourceGroup" -ForegroundColor White
    Write-Host "Region                  : $location" -ForegroundColor White
    Write-Host ""
    Write-Host "RESEAU" -ForegroundColor Cyan
    Write-Host "  VNet                  : $vnetName ($vnetPrefix)" -ForegroundColor White
    Write-Host "  Sous-reseau           : $subnetName ($subnetPrefix)" -ForegroundColor White
    Write-Host ""
    Write-Host "BASE DE DONNEES" -ForegroundColor Cyan
    Write-Host "  Serveur MySQL         : $mysqlServerName" -ForegroundColor White
    Write-Host "  Base de donnees       : $mysqlDatabase" -ForegroundColor White
    Write-Host "  Utilisateur admin     : $mysqlAdminUser" -ForegroundColor White
    Write-Host ""
    Write-Host "SECURITE" -ForegroundColor Cyan
    Write-Host "  Key Vault             : $keyVaultName" -ForegroundColor White
    Write-Host "  Managed Identity      : Activee sur $webAppName" -ForegroundColor White
    Write-Host "  Secrets stockes       : 5 secrets MySQL" -ForegroundColor White
    Write-Host ""
    Write-Host "APPLICATION WEB" -ForegroundColor Cyan
    Write-Host "  App Service Plan      : $appServicePlan" -ForegroundColor White
    Write-Host "  Web App               : $webAppName" -ForegroundColor White
    Write-Host "  Runtime               : Node.js 18 LTS" -ForegroundColor White
    Write-Host "  URL                   : https://$webAppName.azurewebsites.net" -ForegroundColor White
    Write-Host ""
    Write-Host "STOCKAGE" -ForegroundColor Cyan
    Write-Host "  Storage Account       : $storageAccountName" -ForegroundColor White
    Write-Host "  Conteneur logs        : Cree" -ForegroundColor White
    Write-Host ""
    Write-Host "SUPERVISION" -ForegroundColor Cyan
    Write-Host "  VM                    : $vmName" -ForegroundColor White
    Write-Host "  Utilisateur           : $vmAdminUser" -ForegroundColor White
    Write-Host "  OS                    : Ubuntu 22.04" -ForegroundColor White
    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Green
    Write-Host "               PROCHAINES ETAPES" -ForegroundColor Green
    Write-Host "============================================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "1. Deployer le code de l'application:" -ForegroundColor Yellow
    Write-Host "   az webapp deployment source config-zip -g $resourceGroup -n $webAppName --src app.zip" -ForegroundColor White
    Write-Host ""
    Write-Host "2. Tester l'application:" -ForegroundColor Yellow
    Write-Host "   https://$webAppName.azurewebsites.net" -ForegroundColor White
    Write-Host ""
    Write-Host "3. Se connecter a la VM de supervision:" -ForegroundColor Yellow
    Write-Host "   ssh $vmAdminUser@<IP_PUBLIQUE>" -ForegroundColor White
    Write-Host ""
    Write-Host "4. Verifier les secrets Key Vault:" -ForegroundColor Yellow
    Write-Host "   az keyvault secret list --vault-name $keyVaultName " -ForegroundColor White
    Write-Host ""
    Write-Host "5. Pour nettoyer toutes les ressources:" -ForegroundColor Yellow
    Write-Host "   az group delete --name $resourceGroup --yes --no-wait" -ForegroundColor White
    Write-Host ""

} catch {
    # ========================================================================
    # GESTION DES ERREURS
    # ========================================================================
    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Red
    Write-Host "            ERREUR DE DEPLOIEMENT" -ForegroundColor Red
    Write-Host "============================================================" -ForegroundColor Red
    Write-Host ""
    Write-Host "Message d'erreur: " -ForegroundColor Red -NoNewline
    Write-Host $_.Exception.Message -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Stack trace:" -ForegroundColor Red
    Write-Host $_.ScriptStackTrace -ForegroundColor Gray
    Write-Host ""
    Write-Host "Le deploiement a ete interrompu." -ForegroundColor Yellow
    Write-Host "Pour nettoyer les ressources partiellement creees:" -ForegroundColor Yellow
    Write-Host "   az group delete --name $resourceGroup --yes --no-wait" -ForegroundColor Cyan
    Write-Host ""
    
    # Arret du script avec code d'erreur
    exit 1
}

# ============================================================================
# FIN DU SCRIPT
# ============================================================================