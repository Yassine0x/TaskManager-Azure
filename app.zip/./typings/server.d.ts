
declare interface dbConfigType {
	static host: {	};
}
